CUDA_VISIBLE_DEVICES="0" python /home/QFRC/ZQS/Projects/LLaMA-Factory-main/src/web_demo.py \
    --model_name_or_path /mnt/sdb/ZQS/TF-14B_Merge/TF-14B-Base_epoch200_10G_q81 \
    --template default 



# --adapter_name_or_path /home/QFRC/ZQS/Projects/LLaMA-Factory-main/script/TF-14B/Exports/export_50_50 \
# --finetuning_type full
# CUDA_VISIBLE_DEVICES="0"