SFT_TF-14B：微调通义金融大模型脚本

Merge：合并底座大模型和lora adapter，生成金融知识抽取大模型

Quant：量化金融知识抽取大模型尖头FinEX智能体

Web_demo：网页端部署大模型脚本

src：微调大模型所需要的python文件及框架